function saveSchedule() {
  const id = document.getElementById("scheduleId").value;
  const title = document.getElementById("scheduleTitle").value;
  const category_id = parseInt(document.getElementById("scheduleCategory").value, 10);
  const date = document.getElementById("scheduleDate").value;
  const startTime = document.getElementById("scheduleTime").value;
  const endTime = document.getElementById("scheduleEndTime").value;
  const team = document.getElementById("scheduleTeam").value;
  const venue = document.getElementById("scheduleVenue").value;
  const notes = document.getElementById("scheduleNotes").value;

  if (!title || !category_id || !date || !startTime || !endTime) {
    alert("Please fill in all required fields.");
    return;
  }

  const payload = {
    id: id ? parseInt(id, 10) : 0,
    title,
    category_id,
    date,
    startTime,
    endTime,
    venue,
    notes,
    team: team ? team.split(",").map(t => t.trim()) : []
  };

  console.log("Payload being sent:", payload);
  console.log("Request URL:", API_URL);

  fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
    .then(res => {
      console.log("Response received:", {
        status: res.status,
        ok: res.ok,
        url: res.url
      });
      if (!res.ok) {
        throw new Error(`HTTP error! Status: ${res.status} ${res.statusText}`);
      }
      return res.text();
    })
    .then(text => {
      console.log("Raw response:", text);
      if (!text) {
        throw new Error("Empty response from server");
      }
      try {
        const data = JSON.parse(text);
        console.log("Parsed JSON:", data);
        return data;
      } catch (e) {
        console.error("JSON parse error:", e.message, "Raw response:", text);
        throw new Error(`Invalid JSON response: ${text}`);
      }
    })
    .then(data => {
      console.log("Data received:", data);
      if (typeof data !== "object" || data === null) {
        throw new Error("Response is not a valid JSON object");
      }
      if (data.status === "success") {
        alert(id ? "Schedule updated successfully!" : "Schedule created successfully!");
        fetchSchedulesFromServer();
        hideNewScheduleForm();
        resetForm();
      } else {
        alert("Save failed: " + (data.message || "Unknown error"));
      }
    })
    .catch(err => {
      console.error("Fetch error:", err);
      alert("Request failed: " + err.message);
    });
}

function resetForm() {
  const form = document.getElementById("newSchedule");
  if (form) form.reset();
  document.getElementById("scheduleId").value = "";
  document.getElementById("createScheduleBtn").textContent = "Create";
}

document.addEventListener("DOMContentLoaded", () => {
  const createBtn = document.getElementById("createScheduleBtn");
  if (createBtn) {
    createBtn.addEventListener("click", (e) => {
      e.preventDefault();
      saveSchedule();
    });
  }
  fetchSchedulesFromServer();
});


function saveSchedule() {
  const id = document.getElementById("scheduleId").value;
  const title = document.getElementById("scheduleTitle").value;
  const category_id = parseInt(document.getElementById("scheduleCategory").value, 10);
  const date = document.getElementById("scheduleDate").value;
  const startTime = document.getElementById("scheduleTime").value;
  const endTime = document.getElementById("scheduleEndTime").value;
  const team = document.getElementById("scheduleTeam").value;
  const venue = document.getElementById("scheduleVenue").value;
  const notes = document.getElementById("scheduleNotes").value;

  if (!title || !category_id || !date || !startTime || !endTime) {
    alert("Please fill in all required fields.");
    return;
  }

  const payload = {
    id: id ? parseInt(id, 10) : 0,
    title,
    category_id,
    date,
    startTime,
    endTime,
    venue,
    notes,
    team: team ? team.split(",").map(t => t.trim()) : []
  };

  console.log("Payload being sent:", payload);
  console.log("Request URL:", API_URL);

  fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
    .then(res => {
      console.log("Response received:", {
        status: res.status,
        ok: res.ok,
        url: res.url
      });
      if (!res.ok) {
        throw new Error(`HTTP error! Status: ${res.status} ${res.statusText}`);
      }
      return res.text();
    })
    .then(text => {
      console.log("Raw response:", text);
      if (!text) {
        throw new Error("Empty response from server");
      }
      try {
        const data = JSON.parse(text);
        console.log("Parsed JSON:", data);
        return data;
      } catch (e) {
        console.error("JSON parse error:", e.message, "Raw response:", text);
        throw new Error(`Invalid JSON response: ${text}`);
      }
    })
    .then(data => {
      console.log("Data received:", data);
      if (typeof data !== "object" || data === null) {
        throw new Error("Response is not a valid JSON object");
      }
      if (data.status === "success") {
        alert(id ? "Schedule updated successfully!" : "Schedule created successfully!");
        fetchSchedulesFromServer();
        hideNewScheduleForm();
        resetForm();
      } else {
        alert("Save failed: " + (data.message || "Unknown error"));
      }
    })
    .catch(err => {
      console.error("Fetch error:", err);
      alert("Request failed: " + err.message);
    });
}

function resetForm() {
  const form = document.getElementById("newSchedule");
  if (form) form.reset();
  document.getElementById("scheduleId").value = "";
  document.getElementById("createScheduleBtn").textContent = "Create";
}

document.addEventListener("DOMContentLoaded", () => {
  const createBtn = document.getElementById("createScheduleBtn");
  if (createBtn) {
    createBtn.addEventListener("click", (e) => {
      e.preventDefault();
      saveSchedule();
    });
  }
  fetchSchedulesFromServer();
});