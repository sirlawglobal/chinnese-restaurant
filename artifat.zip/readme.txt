t_menu: true, …}
description
: 
"Set menu containing: [\"&quot;Sweet &amp; Sour Chicken Balls&quot;\",\"&quot;Beef in Black Bean Sauce&quot;\",\"&quot;Special Fried Rice&quot;\"]"
id
: 
4
image_url
: 
null
is_set_menu
: 
true
name
: 
"Menu A - For 1 Person"
price
: 
14.8
[[Prototype]]
: 
Object




