<?php
require_once __DIR__ . '/routes/menu_routes.php';
