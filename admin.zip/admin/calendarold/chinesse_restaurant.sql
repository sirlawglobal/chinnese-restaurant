-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2025 at 12:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chinesse_restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `note` varchar(223) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `note`) VALUES
(1, 'STARTERS', '2025-06-03 14:26:00', ''),
(2, 'SOUP', '2025-06-03 14:26:00', '0'),
(3, 'CHICKEN', '2025-06-03 14:26:00', '0'),
(4, 'BEEF', '2025-06-03 14:26:00', '0'),
(5, 'LAMB', '2025-06-03 14:26:00', '0'),
(6, 'PORK & ROAST PORK', '2025-06-03 14:26:00', '0'),
(7, 'DUCK', '2025-06-03 14:26:00', '0'),
(8, 'SEAFOOD', '2025-06-03 14:26:00', '0'),
(9, 'KING PRAWNS', '2025-06-03 14:26:00', '0'),
(10, 'VEGETABLES', '2025-06-03 14:26:00', '0'),
(11, 'CHOP SUEY (BEANSPROUTS)', '2025-06-03 14:26:00', '0'),
(12, 'SWEET & SOUR', '2025-06-03 14:26:00', '0'),
(13, 'CURRY', '2025-06-03 14:26:00', '0'),
(14, 'RICE', '2025-06-03 14:26:00', 'LARGE EXTRA £'),
(15, 'NOODLES', '2025-06-03 14:26:00', 'LARGE EXTRA £'),
(16, 'NOODLE SOUP', '2025-06-03 14:26:00', '0'),
(17, 'OMELETTE', '2025-06-03 14:26:00', '0'),
(18, 'EXTRAS & DESSERTS', '2025-06-03 14:26:00', '0'),
(19, 'SPECIAL HOUSE MEALS', '2025-06-03 14:26:00', 'All Served in One Container with Boiled Rice (Noodle or Egg Fried Rice 50p Extra)'),
(20, 'SET MENU', '2025-06-03 14:26:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `message_id` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `message_id`, `text`, `is_admin`, `created_at`, `is_read`) VALUES
(1, 1, 'how are you', 1, '2025-06-10 08:18:24', 0),
(2, 3, 'alre', 1, '2025-06-10 08:37:54', 0),
(3, 3, 'hi', 1, '2025-06-10 14:25:03', 0),
(4, 3, 'hi', 1, '2025-06-10 14:25:06', 0),
(5, 3, 'hi', 1, '2025-06-10 14:25:08', 0),
(6, 3, 'hi', 1, '2025-06-10 14:25:10', 0),
(7, 3, 'hi', 1, '2025-06-10 14:25:12', 0),
(8, 3, 'hi', 1, '2025-06-10 14:25:14', 0),
(9, 3, 'hi', 1, '2025-06-10 14:25:15', 0),
(10, 3, 'hi', 1, '2025-06-10 14:25:17', 0),
(11, 3, 'hi', 1, '2025-06-10 14:27:31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ev_categories`
--

CREATE TABLE `ev_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ev_categories`
--

INSERT INTO `ev_categories` (`id`, `name`, `slug`) VALUES
(1, 'Meetings', 'meetings'),
(2, 'Menu Updates', 'menu'),
(3, 'Inventory Checks', 'inventory'),
(4, 'Events', 'events');

-- --------------------------------------------------------

--
-- Table structure for table `inves_categories`
--

CREATE TABLE `inves_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inves_categories`
--

INSERT INTO `inves_categories` (`id`, `name`, `created_at`) VALUES
(1, 'Ketchen tools', '2025-06-11 08:23:39'),
(2, 'Food ingredients', '2025-06-11 08:23:39'),
(3, 'others', '2025-06-11 08:23:39'),
(4, 'Custom', '2025-06-04 13:25:10');

-- --------------------------------------------------------

--
-- Table structure for table `inves_orders`
--

CREATE TABLE `inves_orders` (
  `id` int(11) NOT NULL,
  `vendor_supplier` varchar(50) DEFAULT NULL,
  `status` enum('pending','delivered','shipped','') NOT NULL DEFAULT 'pending',
  `delivery_date` date DEFAULT NULL,
  `unit_price` decimal(6,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(6,2) NOT NULL,
  `received` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inves_orders`
--

INSERT INTO `inves_orders` (`id`, `vendor_supplier`, `status`, `delivery_date`, `unit_price`, `quantity`, `total_price`, `received`, `created_at`) VALUES
(1, 'General Food', 'delivered', '2025-06-12', 3.50, 1, 3.50, 1, '2025-06-11 08:58:04'),
(2, 'General Food', 'pending', '2025-06-12', 3.00, 1, 3.00, 1, '2025-06-11 08:58:04'),
(3, 'General Food', 'shipped', '2025-06-12', 10.75, 100, 1075.00, 1, '2025-06-11 08:58:04'),
(4, 'akanji', 'delivered', '2025-06-12', 14.00, 2, 45.00, 1, '2025-06-11 08:58:04'),
(5, 'akanji', 'shipped', '2025-06-12', 4.00, 1, 4.00, 1, '2025-06-11 08:58:04'),
(6, 'akanji', 'shipped', '2025-06-12', 3.00, 1, 45.00, 1, '2025-06-11 08:58:04'),
(7, 'Food', 'pending', '2025-06-12', 5.00, 1, 5.00, 1, '2025-06-11 08:58:04'),
(8, 'Food', 'delivered', '2025-06-12', 6.00, 1, 6.00, 1, '2025-06-11 08:58:04'),
(23, 'chfdee', 'delivered', '2025-06-11', 34.00, 43, 1462.00, 0, '2025-06-11 13:48:57'),
(24, 'cjdjkskisw', 'shipped', '2025-06-12', 48.00, 4, 192.00, 0, '2025-06-11 13:50:48'),
(25, 'charlesed', 'delivered', '2025-06-12', 34.00, 29, 986.00, 0, '2025-06-11 13:50:48');

-- --------------------------------------------------------

--
-- Table structure for table `inves_order_items`
--

CREATE TABLE `inves_order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inves_order_items`
--

INSERT INTO `inves_order_items` (`id`, `order_id`, `item_name`, `category_id`, `price`, `quantity`) VALUES
(1, 1, 'Steamed Rice', 1, 3.50, 1),
(2, 1, 'Steamed Rice', 1, 3.50, 1),
(3, 1, 'Steamed Rice', 1, 3.50, 1),
(4, 2, 'Hot and Sour Soup', 1, 3.00, 1),
(5, 2, 'Hot and Sour Soup', 1, 3.00, 1),
(6, 2, 'Hot and Sour Soup', 1, 3.00, 1),
(7, 3, 'Orange Chicken', 1, 10.75, 100),
(8, 3, 'Orange Chicken', 1, 10.75, 100),
(9, 3, 'Orange Chicken', 1, 10.75, 100),
(10, 4, 'Kung Pao Shrimp', 3, 15.00, 1),
(11, 4, 'Vegetable Lo Mein', 1, 9.75, 1),
(12, 4, 'Dumplings', 1, 8.00, 1),
(13, 5, 'Brown Rice', 2, 4.00, 1),
(14, 5, 'Brown Rice', 2, 4.00, 1),
(15, 5, 'Brown Rice', 2, 4.00, 1),
(16, 5, 'Brown Rice', 2, 4.00, 1),
(17, 6, 'Sweet and Sour Chicken', 1, 13.00, 1),
(18, 6, 'Noodles', 1, 7.50, 2),
(19, 6, 'Lemonade', 2, 3.00, 1),
(20, 7, 'Fried Rice', 1, 5.00, 1),
(21, 7, 'Fried Rice', 1, 5.00, 1),
(22, 7, 'Fried Rice', 1, 5.00, 1),
(23, 8, 'Vegetable Fried Rice', 2, 6.00, 1),
(24, 8, 'Vegetable Fried Rice', 2, 6.00, 1),
(25, 8, 'Vegetable Fried Rice', 2, 6.00, 1),
(39, 23, 'we cas', 2, 34.00, 43),
(40, 24, 'ccc', 2, 48.00, 4),
(41, 25, 'charlesd', 2, 34.00, 29);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `has_options` tinyint(1) DEFAULT 0,
  `is_set_menu` tinyint(1) DEFAULT 0,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `stock_quantity` int(11) DEFAULT 0,
  `reorder_quantity` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `category_id`, `name`, `description`, `price`, `has_options`, `is_set_menu`, `image_url`, `created_at`, `stock_quantity`, `reorder_quantity`) VALUES
(1, 1, 'Mixed Platter (min for 2)', 'Seaweed, Sesame Prawn On Toast, Chicken Satay, Barbecued Spare Ribs, Vegetarian Spring Rolls', 14.80, 0, 0, NULL, '2025-06-05 10:30:36', 9, 54),
(2, 1, 'Crispy Seaweed', NULL, 5.50, 0, 0, NULL, '2025-06-05 10:31:45', 100, 50),
(3, 1, 'Sesame Prawns on Toast', NULL, 7.00, 0, 0, NULL, '2025-06-05 10:32:10', 100, 50),
(4, 1, 'Crispy Won Ton', 'With Sweet & Sour Sauce', 6.00, 0, 0, NULL, '2025-06-05 10:32:42', 100, 50),
(5, 1, 'Deep Fried King Prawns in Breadcrumbs (8)&#34;,', NULL, 8.50, 0, 0, NULL, '2025-06-05 10:33:38', 100, 50),
(6, 1, 'Grilled Peking Dumplings (6)', NULL, 6.80, 0, 0, NULL, '2025-06-05 10:34:00', 100, 50),
(7, 1, 'Grilled Vegetarian Dumplings (6)', NULL, 6.80, 0, 0, NULL, '2025-06-05 10:34:25', 100, 50),
(8, 1, 'Satay Chicken on Skewers (4)', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:34:48', 100, 50),
(9, 1, 'Satay Beef on Skewers (4)', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:35:10', 100, 50),
(10, 1, 'Satay King Prawn on Skewers (4)', NULL, 8.50, 0, 0, NULL, '2025-06-05 10:35:32', 100, 50),
(11, 1, 'Salt & Pepper King Prawns', NULL, 8.50, 0, 0, NULL, '2025-06-05 10:35:56', 100, 50),
(12, 1, 'Salt & Pepper Chicken Wings (8)', NULL, 6.90, 0, 0, NULL, '2025-06-05 10:36:19', 100, 50),
(13, 1, 'Barbecued Chicken Wings (8)', NULL, 6.90, 0, 0, NULL, '2025-06-05 10:36:39', 100, 50),
(14, 1, 'Barbecued Spare Ribs (dry)', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:36:59', 100, 50),
(15, 1, 'Barbecued Spare Ribs in Sauce', 'BBQ, Curry Or Sweet & Sour', 7.80, 0, 0, NULL, '2025-06-05 10:37:29', 100, 50),
(16, 1, 'Barbecued Spare Ribs in Mandarin Sauce', NULL, 7.80, 0, 0, NULL, '2025-06-05 10:37:47', 100, 50),
(17, 1, 'Salt & Pepper Spare Ribs', NULL, 7.80, 0, 0, NULL, '2025-06-05 10:38:26', 100, 50),
(18, 1, 'Spicy Chilli Chips', NULL, 4.30, 0, 0, NULL, '2025-06-05 10:38:49', 100, 50),
(19, 1, 'Dim Sum - Siu Mai (6)', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:39:08', 100, 50),
(20, 1, 'Spring Roll', NULL, 3.50, 0, 0, NULL, '2025-06-05 10:39:28', 100, 50),
(21, 1, 'Vegetarian Spring Rolls (2)', NULL, 4.20, 0, 0, NULL, '2025-06-05 10:39:45', 100, 50),
(22, 1, 'Prawn Crackers', NULL, 2.80, 0, 0, NULL, '2025-06-05 10:40:06', 100, 50),
(23, 1, 'Crispy Aromatic Duck', 'With Pancakes, Spring Onions, Cucumber & Plum Sauce', NULL, 1, 0, NULL, '2025-06-05 10:41:37', 100, 50),
(24, 2, 'Crab Meat & Sweetcorn Soup', NULL, 5.00, 0, 0, NULL, '2025-06-05 10:42:11', 100, 50),
(25, 2, 'Chicken & Sweetcorn Soup', NULL, 4.50, 0, 0, NULL, '2025-06-05 10:42:32', 100, 50),
(26, 2, 'Chicken & Mushroom Soup', NULL, 4.50, 0, 0, NULL, '2025-06-05 10:43:16', 100, 50),
(27, 2, 'Chicken & Noodles Soup', NULL, 4.50, 0, 0, NULL, '2025-06-05 10:47:35', 100, 50),
(28, 2, 'Hot & Sour Soup', NULL, 4.80, 0, 0, NULL, '2025-06-05 10:47:58', 100, 50),
(29, 2, 'Won Ton Soup', NULL, 5.50, 0, 0, NULL, '2025-06-05 10:48:56', 100, 50),
(30, 2, 'Vegetable Soup', NULL, 4.50, 0, 0, NULL, '2025-06-05 10:49:18', 100, 50),
(31, 3, 'Crispy Shredded Chilli Chicken', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:50:26', 100, 50),
(32, 3, 'Chicken with Green Pepper in Black Bean Sauce', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:50:56', 100, 50),
(33, 3, 'Chicken in Szechuan Style', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:51:15', 100, 50),
(34, 3, 'Chicken with Cashewnuts in Yellow Bean Sauce', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:51:40', 100, 50),
(35, 3, 'Chicken with Cashewnuts', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:52:17', 100, 50),
(36, 3, 'Chicken with Mixed Vegetables', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:52:36', 100, 50),
(37, 3, 'Chicken with Pineapple', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:53:08', 100, 50),
(38, 3, 'Chicken with Mushrooms', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:53:33', 100, 50),
(39, 3, 'Kung Po Chicken (Sweet & Chili Sauce)', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:53:54', 100, 50),
(40, 3, 'Lemon Chicken', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:54:12', 100, 50),
(41, 3, 'Chicken with Ginger & Spring Onion in Oyster Sauce', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:54:29', 100, 50),
(42, 3, 'Chicken in Satay Sauce', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:54:55', 100, 50),
(43, 3, 'Chicken Chinese Style', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:55:16', 100, 50),
(44, 4, 'Crispy Shredded Chilli Beef', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:55:44', 34, 50),
(45, 4, 'Beef with Cashewnuts', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:56:50', 100, 50),
(46, 4, 'Beef with Green Pepper in Black Bean Sauce', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:57:46', 100, 50),
(47, 4, 'Beef with Mushrooms', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:58:29', 100, 50),
(48, 4, 'Beef with Ginger & Spring Onion in Oyster Sauce', NULL, 7.50, 0, 0, NULL, '2025-06-05 10:59:02', 100, 50),
(49, 4, 'Beef with Mixed Vegetables', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:59:23', 100, 50),
(50, 4, 'Beef with Onion', NULL, 7.30, 0, 0, NULL, '2025-06-05 10:59:51', 100, 50),
(51, 4, 'Fillet Steak in Mandarin Sauce', NULL, 13.80, 0, 0, NULL, '2025-06-05 11:03:55', 100, 50),
(52, 4, 'Fillet Steak in Black Bean Sauce', NULL, 13.80, 0, 0, NULL, '2025-06-05 11:04:16', 100, 50),
(53, 4, 'Fillet Steak with Ginger & Spring Onions', NULL, 13.80, 0, 0, NULL, '2025-06-05 11:04:38', 100, 50),
(54, 5, 'Lamb with Ginger & Spring Onions', NULL, 9.80, 0, 0, NULL, '2025-06-05 11:06:11', 100, 50),
(55, 5, 'Lamb with Cashewnuts in Yellow Bean Sauce', NULL, 9.80, 0, 0, NULL, '2025-06-05 11:06:50', 100, 50),
(56, 5, 'Lamb with Green Pepper in Black Bean Sauce', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:07:07', 100, 50),
(57, 5, 'Crispy Aromatic Lamb', 'With Pancakes, Spring Onions, Cucumber & Plum Sauce', 13.80, 0, 0, NULL, '2025-06-05 11:07:40', 100, 50),
(58, 6, 'Pork with Green Pepper in Black Bean Sauce', NULL, 7.30, 0, 0, NULL, '2025-06-05 11:08:04', 100, 50),
(59, 6, 'Pork with Mixed Vegetables', NULL, 7.30, 0, 0, NULL, '2025-06-05 11:08:28', 100, 50),
(60, 6, 'Pork with Mushrooms', NULL, 7.30, 0, 0, NULL, '2025-06-05 11:08:50', 100, 50),
(61, 6, 'Pork with Ginger & Spring Onions in Oyster Sauce', NULL, 7.30, 0, 0, NULL, '2025-06-05 11:09:09', 100, 50),
(62, 6, 'Pork with Cashewnuts', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:09:33', 100, 50),
(63, 6, 'Pork with Cashewnuts in Yellow Bean Sauce', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:09:53', 100, 50),
(64, 6, 'Pork Chop in Mandarin Sauce', NULL, 8.50, 0, 0, NULL, '2025-06-05 11:10:12', 100, 50),
(65, 6, 'Pork Chop in Honey Sauce', NULL, 8.50, 0, 0, NULL, '2025-06-05 11:10:46', 100, 50),
(66, 6, 'Roast Pork with Onions', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:11:03', 100, 50),
(67, 6, 'Roast Pork (Char Siu) in Tasty Soya Sauce', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:11:24', 100, 50),
(68, 6, 'Crispy Roast Pork (Belly Pork)', NULL, 9.80, 0, 0, NULL, '2025-06-05 11:11:42', 100, 50),
(69, 7, 'Roast Duck in Tasty Soya Sauce', NULL, 11.00, 0, 0, NULL, '2025-06-05 11:17:29', 100, 50),
(70, 7, 'Duck with Green Pepper in Black Sauce', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:17:29', 100, 50),
(71, 7, 'Duck with Ginger & Spring Onions in Oyster Sauce', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:17:29', 100, 50),
(72, 7, 'Duck with Cashewnuts', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:17:29', 100, 50),
(73, 7, 'Duck with Pineapple', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:17:29', 100, 50),
(74, 7, 'Duck with Mixed Vegetables', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:17:29', 100, 50),
(75, 7, 'Roast Duck Chinese Style', NULL, 9.80, 0, 0, NULL, '2025-06-05 11:17:29', 100, 50),
(76, 7, 'Roast Duck in Lemon Sauce', NULL, 9.80, 0, 0, NULL, '2025-06-05 11:17:29', 100, 50),
(77, 8, 'Lobster with Ginger & Spring Onions', NULL, 29.80, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(78, 8, 'Lobster with Chilli in Black Bean Sauce', NULL, 29.80, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(79, 8, 'Lobster with Salt & Pepper', NULL, 29.80, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(80, 8, 'Crab with Ginger & Spring Onions', NULL, 18.50, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(81, 8, 'Crab with Chilli in Black Bean Sauce', NULL, 18.50, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(82, 8, 'Green Shell Mussels with Chilli in Black Bean Sauce', NULL, 10.50, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(83, 8, 'Squid with Salt & Pepper', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(84, 8, 'Squid with Chilli in Black Bean Sauce', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(85, 8, 'Scallops with Ginger & Spring Onions', NULL, 12.80, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(86, 8, 'Scallops with Chilli in Black Bean Sauce', NULL, 12.80, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(87, 8, 'Fish in Sweet Sour Sauce', NULL, 12.50, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(88, 8, 'Fish in Black Bean Sauce', NULL, 12.50, 0, 0, NULL, '2025-06-05 11:19:36', 100, 50),
(89, 9, 'King Prawns with Cashewnuts', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(90, 9, 'King Prawns with Mixed Vegetables', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(91, 9, 'King Prawns with Chinese Mushrooms in Oyster Sauce', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(92, 9, 'King Prawns with Green Pepper in Black Bean Sauce', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(93, 9, 'King Prawns with Ginger & Spring Onions in Oyster Sauce', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(94, 9, 'King Prawns in Szechuan Style', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(95, 9, 'King Prawns with Mushrooms', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(96, 9, 'Kung Po King Prawns (Sweet & Chilli Hot)', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(97, 9, 'King Prawns with French Beans in Spicy Garlic Sauce', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:21:27', 100, 50),
(98, 10, 'Stir Fried Mixed Vegetables', NULL, 6.50, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(99, 10, 'Mixed Vegetables in Black Bean Sauce', NULL, 6.30, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(100, 10, 'Beancurd in Black Bean Sauce', NULL, 6.30, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(101, 10, 'Beancurd with Chinese Mushrooms & Bamboo Shoots', NULL, 6.50, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(102, 10, 'Stir Fried French Beans in Garlic Sauce', NULL, 6.50, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(103, 10, 'Beancurd in Oyster Sauce', NULL, 6.50, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(104, 10, 'Pak Choi in Garlic Sauce', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(105, 10, 'Stir Fried Mushrooms', NULL, 6.50, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(106, 10, 'Monks Vegetables', NULL, 7.20, 0, 0, NULL, '2025-06-05 11:27:09', 100, 50),
(107, 11, 'Special Chop Suey', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:28:17', 100, 50),
(108, 11, 'King Prawn Chop Suey', NULL, 8.50, 0, 0, NULL, '2025-06-05 11:28:17', 100, 50),
(109, 11, 'Chicken Chop Suey', NULL, 6.90, 0, 0, NULL, '2025-06-05 11:28:17', 100, 50),
(110, 11, 'Beef Chop Suey', NULL, 6.90, 0, 0, NULL, '2025-06-05 11:28:17', 100, 50),
(111, 11, 'Pork Chop Suey', NULL, 6.90, 0, 0, NULL, '2025-06-05 11:28:17', 100, 50),
(112, 11, 'Mushrooms Chop Suey', NULL, 6.50, 0, 0, NULL, '2025-06-05 11:28:17', 100, 50),
(113, 12, 'Sweet & Sour King Prawns (Hong Kong Style)', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(114, 12, 'Sweet & Sour King Prawn Balls (10)', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(115, 12, 'Sweet & Sour Chicken (Hong Kong Style)', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(116, 12, 'Sweet & Sour Chicken Balls (10)', NULL, 8.00, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(117, 12, 'Sweet & Sour Pork (Hong Kong Style)', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(118, 12, 'Sweet & Sour Fried Squid', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(119, 12, 'Sweet & Sour Spare Ribs', NULL, 7.90, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(120, 12, 'Sweet & Sour Mixed Vegetables', NULL, 6.90, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(121, 12, 'Sweet & Sour Sauce', NULL, 2.80, 0, 0, NULL, '2025-06-05 11:29:09', 100, 50),
(122, 13, 'Beef Curry', NULL, 7.30, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(123, 13, 'Chicken Curry', NULL, 7.30, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(124, 13, 'Pork Curry', NULL, 7.30, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(125, 13, 'Lamb Curry', NULL, 8.50, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(126, 13, 'Mixed Meat Curry', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(127, 13, 'King Prawn Curry', NULL, 8.50, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(128, 13, 'Shrimp Curry', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(129, 13, 'Mushroom Curry', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(130, 13, 'Mixed Vegetable Curry', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(131, 13, 'Curry Sauce', NULL, 2.50, 0, 0, NULL, '2025-06-05 11:30:11', 100, 50),
(132, 14, 'Golden Dish House Special Rice', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(133, 14, 'Special Fried Rice', 'Chicken, Shrimp Pork and Pea', 6.80, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(134, 14, 'Shrimp Fried rice', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(135, 14, 'King Prawn Fried Rice', NULL, 8.30, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(136, 14, 'Chicken Fried Rice', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(137, 14, 'Beef Fried Rice', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(138, 14, 'Pork Fried Rice', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(139, 14, 'Shredded Roast Pork Fried Rice', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(140, 14, 'Mixed Vegetables Fried Rice', NULL, 6.50, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(141, 14, 'Egg Fried Rice', NULL, 4.90, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(142, 14, 'Boiled Rice', NULL, 3.90, 0, 0, NULL, '2025-06-05 11:31:36', 100, 50),
(143, 15, 'Golden Dish House Special Chow Mein', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(144, 15, 'Special Chow Mein', 'Chicken, Shrimp Pork and Pea', 6.80, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(145, 15, 'Shrimp Chow Mein', NULL, 7.20, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(146, 15, 'King Prawn Chow Mein', NULL, 8.30, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(147, 15, 'Chicken Chow Mein', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(148, 15, 'Beef Chow Mein', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(149, 15, 'Pork Chow Mein', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(150, 15, 'Shredded Roast Pork Chow Mein', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(151, 15, 'Mixed Vegetables Chow Mein', NULL, 6.50, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(152, 15, 'Plain Chow Mein', NULL, 5.30, 0, 0, NULL, '2025-06-05 11:34:05', 100, 50),
(153, 16, 'Roast Duck with Noodle Soup', NULL, 9.50, 0, 0, NULL, '2025-06-05 11:34:52', 100, 50),
(154, 16, 'Roast Pork with Noodle Soup', NULL, 9.00, 0, 0, NULL, '2025-06-05 11:34:52', 100, 50),
(155, 16, 'Roast Chicken with Noodle Soup', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:34:52', 100, 50),
(156, 16, 'Won Ton Noodle Soup', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:34:52', 100, 50),
(157, 17, 'Special Omelette', NULL, 6.90, 0, 0, NULL, '2025-06-05 11:35:27', 100, 50),
(158, 17, 'King Prawn Omelette', NULL, 8.30, 0, 0, NULL, '2025-06-05 11:35:27', 100, 50),
(159, 17, 'Chicken Omelette', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:35:27', 100, 50),
(160, 17, 'Roast Pork Omelette', NULL, 7.00, 0, 0, NULL, '2025-06-05 11:35:27', 100, 50),
(161, 17, 'Mushroom Omelette', NULL, 6.80, 0, 0, NULL, '2025-06-05 11:35:27', 100, 50),
(162, 17, 'Plain Omelette', NULL, 5.50, 0, 0, NULL, '2025-06-05 11:35:27', 100, 50),
(163, 18, 'Chips', NULL, 3.50, 0, 0, NULL, '2025-06-05 11:36:39', 100, 50),
(164, 18, 'Chilli Oil', NULL, 2.90, 0, 0, NULL, '2025-06-05 11:36:39', 100, 50),
(165, 18, 'Sweet Chilli Sauce', NULL, 2.90, 0, 0, NULL, '2025-06-05 11:36:39', 100, 50),
(166, 18, 'Barbecued Sauce', NULL, 2.90, 0, 0, NULL, '2025-06-05 11:36:39', 100, 50),
(167, 18, 'Plum Sauce', NULL, 3.30, 0, 0, NULL, '2025-06-05 11:36:39', 100, 50),
(168, 18, 'Banana Fritter in Syrup', NULL, 5.00, 0, 0, NULL, '2025-06-05 11:36:39', 100, 50),
(169, 18, 'Apple Fritter in Syrup', NULL, 5.00, 0, 0, NULL, '2025-06-05 11:36:39', 100, 50),
(170, 18, 'Pineapple Fritter in Syrup', NULL, 5.00, 0, 0, NULL, '2025-06-05 11:36:39', 100, 50),
(172, 19, 'Chicken / Beef or Pork with Green Pepper in Black Bean Sauce', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(173, 19, 'Chicken / Beef or Pork with Mixed Vegetables', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(174, 19, 'Chicken / Beef or Pork in Satay Sauce', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(175, 19, 'Spare Ribs with Green Pepper in Black Bean Sauce', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(176, 19, 'Roast Chicken', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(177, 19, 'Roast Pork', NULL, 8.50, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(178, 19, 'Roast Duck', NULL, 9.00, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(179, 19, 'Singapore Fried Rice', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(180, 19, 'Singapore Fried Noodles', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(181, 19, 'Singapore Vermicelli Rice Noodles', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(182, 19, 'Vegetarian Singapore Noodles', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(183, 19, 'Mixed Vegetables', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(184, 19, 'Sweet & Sour Chicken', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(185, 19, 'Sweet & Sour Pork', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(186, 19, 'Chicken with Cashewnuts', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(187, 19, 'Crispy Chilii Beef', NULL, 7.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(188, 19, 'Beancurd with Mixed Vegetables', NULL, 7.50, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(189, 19, 'Mixed Seafood (King Prawns, Squid, Scallops)', NULL, 9.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(190, 19, 'Squid in Black Bean Sauce', NULL, 9.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(191, 19, 'King Prawns with Mixed Vegetables', NULL, 8.80, 0, 0, NULL, '2025-06-05 11:40:59', 100, 50),
(192, 20, 'Menu A - For 1 Person', NULL, NULL, 0, 1, NULL, '2025-06-05 11:44:06', 100, 50),
(193, 20, 'Menu B - For 2 Persons', NULL, NULL, 0, 1, NULL, '2025-06-05 11:45:13', 100, 50),
(194, 20, 'Menu C - For 2 Persons', NULL, NULL, 0, 1, NULL, '2025-06-05 11:45:55', 100, 50),
(195, 20, 'Menu D - For 2 Persons', NULL, NULL, 0, 1, NULL, '2025-06-05 11:46:41', 100, 50),
(196, 20, 'Menu E - For 3 Persons', NULL, NULL, 0, 1, NULL, '2025-06-05 11:47:30', 100, 50),
(197, 17, 'dog', NULL, NULL, 1, 0, NULL, '2025-06-07 16:11:31', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `item_options`
--

CREATE TABLE `item_options` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `portion` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_options`
--

INSERT INTO `item_options` (`id`, `item_id`, `portion`, `price`) VALUES
(1, 23, '1/4 (6 pancakes)', 13.50),
(2, 23, '1/2 (12 pancakes)', 21.80),
(3, 23, 'Whole (24 pancakes)', 36.80),
(4, 197, '34', 0.04);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('sent','failed','read') DEFAULT 'sent',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `telephone`, `message`, `status`, `created_at`) VALUES
(1, 'Balogun Ayomiposi', 'balpos07@gmail.com', '09157874468', 'how are you', '', '2025-06-10 08:18:24'),
(2, 'Charles', 'charlesebuka162@gmail.com', '5656677734', 'please help okay', 'sent', '2025-06-10 08:20:36'),
(3, 'Balogun Ayomiposi', 'charlesebuka162@gmail.com', '09157874468', 'hi', '', '2025-06-10 14:27:31'),
(4, 'Gbenga', 'ayodeleoluwagbemiga2@gmail.com', '09060288600', 'Sample testing', 'sent', '2025-06-10 14:28:48');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tx_ref` varchar(50) NOT NULL,
  `delivery_address` text NOT NULL,
  `order_notes` text DEFAULT NULL,
  `order_type` enum('now','schedule') NOT NULL,
  `schedule_date` date DEFAULT NULL,
  `schedule_time` time DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `transaction_id` varchar(50) DEFAULT NULL,
  `guest_email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `portion` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `dish_id` int(11) NOT NULL,
  `dish_name` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `reviewer_name` varchar(100) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `review_text` text NOT NULL,
  `review_date` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `dish_id`, `dish_name`, `category_name`, `reviewer_name`, `rating`, `review_text`, `review_date`, `created_at`) VALUES
(1, 46, 'Beef with Green Pepper in Black Bean Sauce', 'BEEF', 'sxxs', 3, 'Review', '2025-06-09 16:53:56', '2025-06-09 15:53:56');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `start_time` varchar(10) DEFAULT NULL,
  `end_time` varchar(10) DEFAULT NULL,
  `team` text DEFAULT NULL,
  `venue` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `user_id`, `title`, `category`, `date`, `start_time`, `end_time`, `team`, `venue`, `notes`, `created_at`, `category_id`) VALUES
(1, 1, 'Weekly Specials Review', 'Menu Updates', '2025-06-14', '15:00', '16:00', '[\"HC\", \"SC\", \"+3\"]', 'Kitchen', 'Finalize weekly specials.', '2025-06-12 18:37:05', 3),
(2, 1, 'Inventory Check', 'Inventory', '2025-06-15', '10:00', '11:30', '[\"JM\", \"AO\"]', 'Store Room', 'Review current stock.', '2025-06-12 18:37:05', 2),
(3, 1, 'Morning Briefing', 'Team Check-in', '2025-06-16', '09:00', '09:30', '[\"HC\", \"Team Lead\"]', 'Meeting Room 1', 'Discuss daily goals.', '2025-06-12 18:37:05', 1),
(4, 1, 'Vendor Meeting', 'Meetings', '2025-06-17', '13:00', '14:00', '[\"MD\", \"Procurement Team\"]', 'Office', 'Talk with new vegetable suppliers.', '2025-06-12 18:37:05', 1),
(5, 1, 'Seasonal Tasting', 'New Dish', '2025-06-18', '11:00', '12:00', '[\"SC\", \"Kitchen Team\"]', 'Kitchen', 'Try out seasonal menu options.', '2025-06-12 18:37:05', 3),
(6, 2, 'Event Planning', 'Events', '2025-06-19', '14:00', '15:30', '[\"AO\", \"SC\", \"Marketing\"]', 'Main Hall', 'Plan for weekend event.', '2025-06-12 18:37:05', 2),
(7, 2, 'Customer Feedback Review', 'Meetings', '2025-06-20', '16:00', '17:00', '[\"MD\", \"HC\"]', 'Conference Room', 'Review customer feedback forms.', '2025-06-12 18:37:05', 3),
(8, 2, 'Fridge Maintenance', 'Inventory', '2025-06-21', '08:30', '09:30', '[\"Maintenance Team\"]', 'Cold Room', 'Check fridge status.', '2025-06-12 18:37:05', 2),
(9, 2, 'Weekly Review', 'Team Check-in', '2025-06-22', '10:00', '11:00', '[\"SC\", \"HC\", \"+2\"]', 'Office', 'Weekly progress review.', '2025-06-12 18:37:05', 3),
(10, 2, 'Birthday Celebration', 'Events', '2025-06-23', '17:00', '18:00', '[\"All Staff\"]', 'Lounge', 'Celebrate staff birthdays.', '2025-06-12 18:37:05', 1),
(11, 2, 'let', 'let', '2025-06-11', '12:30', '12:02', '[\"let\"]', 'let', 'let', '2025-06-12 18:57:35', 3),
(12, 1, 'let1', 'let1', '2025-06-12', '12:30', '22:02', '[\"let2\"]', 'jdd', 'xjs', '2025-06-12 19:13:54', 3);

-- --------------------------------------------------------

--
-- Table structure for table `set_menus`
--

CREATE TABLE `set_menus` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `items` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`items`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `set_menus`
--

INSERT INTO `set_menus` (`id`, `item_id`, `name`, `price`, `items`) VALUES
(1, 192, 'Menu A - For 1 Person', 14.80, '[\"&quot;Sweet &amp; Sour Chicken Balls&quot;\",\"&quot;Beef in Black Bean Sauce&quot;\",\"&quot;Special Fried Rice&quot;\"]'),
(2, 193, 'Menu B - For 2 Persons', 25.80, '[\"&quot;Crispy Seaweed&quot;\",\"&quot;Sesame Prawns on Toast&quot;\",\"&quot;Chicken with Cashewnuts in Yellow Bean Sauce&quot;\",\"&quot;Sweet &amp; Sour Pork (Hong Kong Style)&quot;\",\"&quot;Special Fried Rice&quot;\"]'),
(3, 194, 'Menu C - For 2 Persons', 36.80, '[\"&quot;Crispy Seaweed&quot;\",\"&quot;Sesame Prawn on Toast&quot;\",\"&quot;Kung Po Chicken&quot;\",\"&quot;Beef with Mixed Vegetables&quot;\",\"&quot;Roast Pork in Tasty Soya Sauce&quot;\",\"&quot;Special Fried Rice&quot;\"]'),
(4, 195, 'Menu D - For 2 Persons', 42.80, '[\"&quot;Crispy Seaweed&quot;\",\"&quot;Satay Chicken on Skewer (4)&quot;\",\"&quot;Salt &amp; Pepper Spare Ribs&quot;\",\"&quot;Chicken with Ginger &amp; Spring Onions in Oyster Sauce&quot;\",\"&quot;Beef with Cashewnuts&quot;\",\"&quot;Sweet &amp; Sour Pork&quot;\",\"&quot;Special Fried Rice&quot;\"]'),
(5, 196, 'Menu E - For 3 Persons', 51.80, '[\"&quot;Crispy Seaweed&quot;\",\"&quot;Sesame Prawn on Toast&quot;\",\"&quot;Spare Ribs in Mandarin Sauce&quot;\",\"&quot;Crispy Aromatic Duck with Pancakes&quot;\",\"&quot;Crispy Chilli Beef&quot;\",\"&quot;Chicken in Black Bean Sauce&quot;\",\"&quot;Pork with Cashewnuts&quot;\",\"&quot;Special Fried Rice&quot;\"]');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('admin','user','','') DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `role`, `password`, `created_at`) VALUES
(1, 'akanji', '08165999946', 'tessanota@ehicentre.org.b', '', '$2y$10$m.wZ7fOCR9.ExcHuRyqHj.X7hxW1XmQ7sKpyerT0AnYzU8qCt7FGC', '2025-06-06 16:20:24'),
(2, 'akanji', '08165999946', 'akanjilawrence9999@gmail.com', 'admin', '$2y$10$2s361P738S3Xv092oErrmeL4OkNjmJ..NWcxKz3/laghIRwTbj91i', '2025-06-06 16:22:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_message_id` (`message_id`);

--
-- Indexes for table `ev_categories`
--
ALTER TABLE `ev_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `inves_categories`
--
ALTER TABLE `inves_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inves_orders`
--
ALTER TABLE `inves_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inves_order_items`
--
ALTER TABLE `inves_order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `item_options`
--
ALTER TABLE `item_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tx_ref` (`tx_ref`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dish_id` (`dish_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `set_menus`
--
ALTER TABLE `set_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ev_categories`
--
ALTER TABLE `ev_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `inves_categories`
--
ALTER TABLE `inves_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `inves_orders`
--
ALTER TABLE `inves_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `inves_order_items`
--
ALTER TABLE `inves_order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200;

--
-- AUTO_INCREMENT for table `item_options`
--
ALTER TABLE `item_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `set_menus`
--
ALTER TABLE `set_menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `item_options`
--
ALTER TABLE `item_options`
  ADD CONSTRAINT `item_options_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `set_menus`
--
ALTER TABLE `set_menus`
  ADD CONSTRAINT `set_menus_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
