<?php
header('Content-Type: application/json');

require_once '../../config/db.php';

try {
    // Fetch all categories
    $categoriesStmt = $pdo->prepare("
        SELECT id, name, created_at 
        FROM categories 
        ORDER BY name ASC
    ");
    $categoriesStmt->execute();
    $categories = $categoriesStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch all regular items
    $itemsStmt = $pdo->prepare("
        SELECT 
            id,
            category_id,
            name,
            description,
            price,
            has_options,
            image_url
        FROM items
        WHERE is_set_menu = 0
    ");
    $itemsStmt->execute();
    $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch options for items that have options
    $optionsStmt = $pdo->prepare("
        SELECT 
            item_id,
            `portion`,
            price
        FROM item_options
    ");
    $optionsStmt->execute();
    $allOptions = $optionsStmt->fetchAll(PDO::FETCH_GROUP|PDO::FETCH_ASSOC);

    // Fetch set menus
    $setMenusStmt = $pdo->prepare("
        SELECT 
            id,
            name,
            price,
            items
        FROM set_menus
    ");
    $setMenusStmt->execute();
    $setMenus = $setMenusStmt->fetchAll(PDO::FETCH_ASSOC);

    // Process regular items
    foreach ($items as &$item) {
        $itemId = $item['id'];
        $item['options'] = [];
        
        if ($item['has_options'] && isset($allOptions[$itemId])) {
            $item['options'] = $allOptions[$itemId];
        }
        
        // Convert price to float
        $item['price'] = (float)$item['price'];
    }

    // Process set menus
    $setMenuCategory = [
        'id' => 0,
        'name' => 'Set Menus',
        'created_at' => null,
        'items' => []
    ];

    foreach ($setMenus as $setMenu) {
        $setMenuCategory['items'][] = [
            'id' => $setMenu['id'],
            'name' => $setMenu['name'],
            'description' => 'Set menu containing: ' . $setMenu['items'],
            'price' => (float)$setMenu['price'],
            'is_set_menu' => true,
            'image_url' => null
        ];
    }

    // Organize items by category
    $menuData = [];
    foreach ($categories as $category) {
        $categoryItems = array_filter($items, function($item) use ($category) {
            return $item['category_id'] == $category['id'];
        });

        $menuData[] = [
            'id' => (int)$category['id'],
            'name' => $category['name'],
            'items' => array_values($categoryItems)
        ];
    }

    // Add set menus as a special category if they exist
    if (!empty($setMenuCategory['items'])) {
        $menuData[] = $setMenuCategory;
    }

    // Successful response
    echo json_encode([
        'status' => 'success',
        'data' => [
            'categories' => $menuData
        ],
        'timestamp' => time()
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error',
        'error_code' => $e->getCode(),
        'error_info' => $e->getMessage()
    ]);
    error_log("PDO Error: " . $e->getMessage());
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
    error_log("Error: " . $e->getMessage());
}