<?php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
require_once '../../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => '', 'item_id' => null, 'image_url' => null];

    try {
        // Input validation
        $category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
        $name = trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING));
        $description = trim(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING));
        $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT, ['options' => ['min_range' => 0]]);
        $has_options = (isset($_POST['has_options']) && $_POST['has_options'] === 'true') ? 1 : 0;
        $is_set_menu = (isset($_POST['is_set_menu']) && $_POST['is_set_menu'] === 'true') ? 1 : 0;


        if (!$category_id || empty($name)) {
            throw new Exception('Category and Item Name are required.');
        }

        // Image handling
        $image_url = null;
        if (!$has_options && !$is_set_menu && isset($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image_url = uploadImage($_FILES['image']);
            if (!$image_url) {
                throw new Exception('Failed to upload image. Check file type or size.');
            }
        }

        $pdo->beginTransaction();

        // Insert main item
        $stmt = $pdo->prepare("
            INSERT INTO items (category_id, name, description, price, has_options, is_set_menu, image_url)
            VALUES (:category_id, :name, :description, :price, :has_options, :is_set_menu, :image_url)
        ");
        $stmt->execute([
            ':category_id' => $category_id,
            ':name' => $name,
            ':description' => !empty($description) ? $description : null,
            ':price' => $price !== false ? $price : null,
            ':has_options' => $has_options,
            ':is_set_menu' => $is_set_menu,
            ':image_url' => $image_url
        ]);
        $item_id = $pdo->lastInsertId();

      
if ($has_options && !empty($_POST['options'])) {
    $options = json_decode($_POST['options'], true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid options format: ' . json_last_error_msg());
    }


   if (!empty($options)) {
    try {
        // Get the last inserted item ID once outside the loop
        $item_id_int = (int)$pdo->lastInsertId();
        
        $stmt = $pdo->prepare("
            INSERT INTO item_options (item_id, `portion`, price)
            VALUES (:item_id, :portion, :price)
        ");

        foreach ($options as $option) {
            if (!empty($option['portion']) && isset($option['price'])) {
                // Enhanced debugging
                $debugData = [
                    'item_id' => $item_id,
                    'portion' => $option['portion'],
                    'price' => floatval($option['price']),
                    'types' => [
                        'item_id' => gettype($item_id_int),
                        'portion' => gettype($option['portion']),
                        'price' => gettype(floatval($option['price']))
                    ]
                ];
                file_put_contents('debug.log', print_r($debugData, true), FILE_APPEND);

                // Clear any previous parameters
                $stmt->closeCursor();
                
                // Bind with explicit types
                $stmt->bindValue(':item_id', $item_id_int, PDO::PARAM_INT);
                $stmt->bindValue(':portion', $option['portion'], PDO::PARAM_STR);
                $stmt->bindValue(':price', floatval($option['price']), PDO::PARAM_STR);
                
                if (!$stmt->execute()) {
                    $errorInfo = $stmt->errorInfo();
                    file_put_contents('debug.log', "SQL Error: " . print_r($errorInfo, true) . "\n", FILE_APPEND);
                    throw new Exception("Database error: " . $errorInfo[2]);
                }
            }
        }
    } catch (PDOException $e) {
        file_put_contents('debug.log', "PDO Exception: " . $e->getMessage() . "\n", FILE_APPEND);
        throw new Exception("Database error: " . $e->getMessage());
    }
}
   
}
        // Handle set menu
        if ($is_set_menu && !empty($_POST['set_menu'])) {
            $set_menu = json_decode($_POST['set_menu'], true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($set_menu)) {
                throw new Exception('Invalid set menu format.');
            }

            $setMenuPrice = isset($set_menu['price']) ? 
                filter_var($set_menu['price'], FILTER_VALIDATE_FLOAT, ['options' => ['min_range' => 0]]) : 
                0;

            $menuItems = [];
            if (!empty($set_menu['items']) && is_array($set_menu['items'])) {
                foreach ($set_menu['items'] as $item) {

 $debugData = [
                    'item_id' => $item_id,
                   
                    'types' => [
                        'item_id' => gettype($item_id),
                     
                    ]
                ];
                file_put_contents('debug.log', print_r($debugData, true), FILE_APPEND);

                    if (!empty($item)) {
                        $menuItems[] = htmlspecialchars($item);
                    }
                }
            }

            $stmt = $pdo->prepare("
                INSERT INTO set_menus (item_id, name, price, items)
                VALUES (:item_id, :name, :price, :items)
            ");
            $stmt->execute([
                ':item_id' => $item_id,
                ':name' => !empty($set_menu['name']) ? htmlspecialchars($set_menu['name']) : $name,
                ':price' => $setMenuPrice !== false ? $setMenuPrice : 0,
                ':items' => json_encode($menuItems)
            ]);
        }

        $pdo->commit();

        $response['success'] = true;
        $response['message'] = 'Menu item added successfully!';
        $response['item_id'] = $item_id;
        $response['image_url'] = $image_url;

    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $response['message'] = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $response['message'] = 'Error: ' . $e->getMessage();
    }

    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}


?>