<?php
header('Content-Type: application/json');

require_once '../../config/db.php';

if (!isset($_GET['id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Category ID is required']);
    exit;
}

$categoryId = (int) $_GET['id'];

try {
    $stmt = $pdo->prepare("SELECT id, name FROM categories WHERE id = ?");
    $stmt->execute([$categoryId]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($category) {
        echo json_encode([
            'status' => 'success',
            'data' => $category
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Category not found'
        ]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error',
        'error_info' => $e->getMessage()
    ]);
}
